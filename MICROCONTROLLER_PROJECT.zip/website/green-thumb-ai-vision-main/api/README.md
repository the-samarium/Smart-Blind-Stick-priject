
# PHP API for ESP Sensor Data

This API provides endpoints for receiving and retrieving sensor data from ESP devices.

## Endpoints

### 1. Receive Data: `/api/receive_data.php`
- **Method**: POST
- **Purpose**: Receives sensor data from ESP devices
- **Request Body**: JSON with the following structure:
  ```json
  {
    "nitrogen": 50,
    "phosphorus": 40,
    "potassium": 60,
    "batteryLevel": 80,
    "pumpStatus": {
      "nitrogen": "OFF",
      "phosphorus": "OFF",
      "potassium": "OFF"
    },
    "autoMode": false
  }
  ```
- **Response**: Success/Error message

### 2. Get Latest Data: `/api/receive_data.php`
- **Method**: GET
- **Purpose**: Retrieves the latest sensor data
- **Response**: JSON with the latest sensor data

### 3. Get Historical Data: `/api/get_history.php`
- **Method**: GET
- **Query Parameters**: `days` (optional, default: 7)
- **Purpose**: Retrieves historical sensor data for the specified number of days
- **Response**: JSON array of sensor data points

### 4. Control Pump: `/api/control_pump.php`
- **Method**: POST
- **Purpose**: Controls the state of a specific nutrient pump
- **Request Body**:
  ```json
  {
    "nutrient": "nitrogen", // or "phosphorus", "potassium"
    "state": "ON" // or "OFF"
  }
  ```
- **Response**: Success/Error message

### 5. Toggle Auto Mode: `/api/toggle_auto.php`
- **Method**: POST
- **Purpose**: Enables or disables auto mode
- **Request Body**:
  ```json
  {
    "autoMode": true // or false
  }
  ```
- **Response**: Success/Error message

## Test Scripts

### Test Data Generation: `/api/test_data.php`
- **Purpose**: Simulates an ESP device sending random data to the API
- **Usage**: Open this URL in a browser to send random test data

## Data Storage

All sensor data is stored in the `data` directory:
- Latest data: `/data/sensor_data.json`
- Historical data: `/data/sensor_history.json`

## Instructions for ESP Device

Program your ESP device to send POST requests to `http://your-server-address/api/receive_data.php` with the JSON data structure shown above.
