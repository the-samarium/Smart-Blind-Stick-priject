
<?php
// Set headers to allow cross-origin requests
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Create a data directory if it doesn't exist
$dataDir = "data";
if (!file_exists($dataDir)) {
    mkdir($dataDir, 0777, true);
}

// Path to the JSON file that will store the latest sensor data
$dataFile = "$dataDir/sensor_data.json";

// Check if this is a POST request with sensor data from ESP
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get the raw POST data
    $postData = file_get_contents("php://input");
    
    // Try to decode the JSON data
    $data = json_decode($postData, true);
    
    // If valid JSON data was received
    if ($data !== null) {
        // Add a timestamp
        $data['timestamp'] = date('Y-m-d H:i:s');
        
        // Ensure we have the required fields or set defaults
        if (!isset($data['nitrogen'])) $data['nitrogen'] = 0;
        if (!isset($data['phosphorus'])) $data['phosphorus'] = 0;
        if (!isset($data['potassium'])) $data['potassium'] = 0;
        if (!isset($data['batteryLevel'])) $data['batteryLevel'] = 0;
        if (!isset($data['pumpStatus'])) {
            $data['pumpStatus'] = [
                'nitrogen' => 'OFF',
                'phosphorus' => 'OFF',
                'potassium' => 'OFF'
            ];
        }
        if (!isset($data['autoMode'])) $data['autoMode'] = false;
        
        // Save the data to the JSON file
        file_put_contents($dataFile, json_encode($data, JSON_PRETTY_PRINT));
        
        // Also append to a history file for retrieving past data
        $historyFile = "$dataDir/sensor_history.json";
        $history = [];
        
        if (file_exists($historyFile)) {
            $historyContent = file_get_contents($historyFile);
            $history = json_decode($historyContent, true) ?: [];
        }
        
        // Add the new data point and limit to last 500 entries
        array_push($history, $data);
        if (count($history) > 500) {
            $history = array_slice($history, -500);
        }
        
        file_put_contents($historyFile, json_encode($history, JSON_PRETTY_PRINT));
        
        // Return success response
        echo json_encode(["status" => "success", "message" => "Data received"]);
    } else {
        // Invalid JSON
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Invalid JSON data"]);
    }
    exit;
}

// For GET requests, return the latest sensor data
if ($_SERVER["REQUEST_METHOD"] === "GET") {
    if (file_exists($dataFile)) {
        echo file_get_contents($dataFile);
    } else {
        // Return default data if no data file exists yet
        echo json_encode([
            "timestamp" => date('Y-m-d H:i:s'),
            "nitrogen" => 50,
            "phosphorus" => 40,
            "potassium" => 60,
            "batteryLevel" => 80,
            "pumpStatus" => [
                "nitrogen" => "OFF",
                "phosphorus" => "OFF",
                "potassium" => "OFF"
            ],
            "autoMode" => false
        ]);
    }
    exit;
}

// For unsupported request methods
http_response_code(405);
echo json_encode(["status" => "error", "message" => "Method not allowed"]);
?>
