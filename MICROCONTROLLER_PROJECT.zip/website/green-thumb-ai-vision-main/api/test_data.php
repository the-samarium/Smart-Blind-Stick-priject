
<?php
// This script simulates an ESP device sending data to the API
// Use this for testing when you don't have a real ESP device

// URL of the receive_data.php script
$apiUrl = "receive_data.php";

// Generate some random sensor data
$data = [
    "nitrogen" => rand(30, 80),
    "phosphorus" => rand(20, 60),
    "potassium" => rand(40, 90),
    "batteryLevel" => rand(20, 100),
    "pumpStatus" => [
        "nitrogen" => (rand(0, 1) ? "ON" : "OFF"),
        "phosphorus" => (rand(0, 1) ? "ON" : "OFF"),
        "potassium" => (rand(0, 1) ? "ON" : "OFF")
    ],
    "autoMode" => (rand(0, 3) > 0) // 75% chance of auto mode being true
];

// Convert data to JSON
$jsonData = json_encode($data);

// Initialize cURL session
$ch = curl_init($apiUrl);

// Set cURL options
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Execute cURL session
$response = curl_exec($ch);

// Check for errors
if (curl_errno($ch)) {
    echo "Error: " . curl_error($ch);
} else {
    echo "Response: " . $response;
}

// Close cURL session
curl_close($ch);

echo "<br><br>Random data sent to API:<br>";
echo "<pre>" . json_encode($data, JSON_PRETTY_PRINT) . "</pre>";
?>
