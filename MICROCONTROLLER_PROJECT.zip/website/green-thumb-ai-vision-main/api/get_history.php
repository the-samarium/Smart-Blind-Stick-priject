
<?php
// Set headers to allow cross-origin requests
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

// Path to the history file
$historyFile = "data/sensor_history.json";

// Check if the history file exists
if (file_exists($historyFile)) {
    // Get the days parameter from query string, default to 7
    $days = isset($_GET['days']) ? intval($_GET['days']) : 7;
    
    // Read the history data
    $historyContent = file_get_contents($historyFile);
    $history = json_decode($historyContent, true) ?: [];
    
    // Filter data for the requested time period
    $cutoffTime = strtotime("-$days days");
    $filteredHistory = array_filter($history, function($item) use ($cutoffTime) {
        return strtotime($item['timestamp']) >= $cutoffTime;
    });
    
    // Return the filtered data
    echo json_encode(array_values($filteredHistory));
} else {
    // Return empty array if no history file exists
    echo json_encode([]);
}
?>
