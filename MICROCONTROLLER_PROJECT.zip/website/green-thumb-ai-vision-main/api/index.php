
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NPK Sensor API</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            color: #333;
        }
        h1 {
            color: #2c7a7b;
        }
        h2 {
            color: #2b6cb0;
        }
        pre {
            background: #f4f5f7;
            padding: 15px;
            border-radius: 5px;
            overflow-x: auto;
        }
        code {
            background: #edf2f7;
            padding: 2px 5px;
            border-radius: 3px;
        }
        .endpoint {
            margin-bottom: 30px;
            border-bottom: 1px solid #e2e8f0;
            padding-bottom: 20px;
        }
        .method {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: bold;
            margin-right: 10px;
        }
        .get {
            background-color: #c6f6d5;
            color: #22543d;
        }
        .post {
            background-color: #bee3f8;
            color: #2c5282;
        }
    </style>
</head>
<body>
    <h1>NPK Sensor API Documentation</h1>
    <p>This API provides endpoints for receiving and retrieving NPK sensor data from ESP devices.</p>
    
    <div class="endpoint">
        <h2>Receive Data</h2>
        <p><span class="method post">POST</span> <code>/api/receive_data.php</code></p>
        <p>Receives sensor data from ESP devices.</p>
        <h3>Request Body:</h3>
        <pre>{
  "nitrogen": 50,
  "phosphorus": 40,
  "potassium": 60,
  "batteryLevel": 80,
  "pumpStatus": {
    "nitrogen": "OFF",
    "phosphorus": "OFF",
    "potassium": "OFF"
  },
  "autoMode": false
}</pre>
        <h3>Response:</h3>
        <pre>{
  "status": "success",
  "message": "Data received"
}</pre>
    </div>
    
    <div class="endpoint">
        <h2>Get Latest Data</h2>
        <p><span class="method get">GET</span> <code>/api/receive_data.php</code></p>
        <p>Retrieves the latest sensor data.</p>
        <h3>Response:</h3>
        <pre>{
  "timestamp": "2025-04-10 12:34:56",
  "nitrogen": 50,
  "phosphorus": 40,
  "potassium": 60,
  "batteryLevel": 80,
  "pumpStatus": {
    "nitrogen": "OFF",
    "phosphorus": "OFF",
    "potassium": "OFF"
  },
  "autoMode": false
}</pre>
    </div>
    
    <div class="endpoint">
        <h2>Get Historical Data</h2>
        <p><span class="method get">GET</span> <code>/api/get_history.php?days=7</code></p>
        <p>Retrieves historical sensor data for the specified number of days.</p>
        <h3>Query Parameters:</h3>
        <ul>
            <li><code>days</code> (optional, default: 7): Number of days of history to retrieve</li>
        </ul>
        <h3>Response:</h3>
        <pre>[
  {
    "timestamp": "2025-04-09 10:30:15",
    "nitrogen": 45,
    "phosphorus": 38,
    "potassium": 62,
    "batteryLevel": 85,
    "pumpStatus": {...},
    "autoMode": true
  },
  // More data points...
]</pre>
    </div>
    
    <div class="endpoint">
        <h2>Control Pump</h2>
        <p><span class="method post">POST</span> <code>/api/control_pump.php</code></p>
        <p>Controls the state of a specific nutrient pump.</p>
        <h3>Request Body:</h3>
        <pre>{
  "nutrient": "nitrogen", // or "phosphorus", "potassium"
  "state": "ON" // or "OFF"
}</pre>
        <h3>Response:</h3>
        <pre>{
  "success": true,
  "message": "Pump control successful",
  "nutrient": "nitrogen",
  "state": "ON"
}</pre>
    </div>
    
    <div class="endpoint">
        <h2>Toggle Auto Mode</h2>
        <p><span class="method post">POST</span> <code>/api/toggle_auto.php</code></p>
        <p>Enables or disables auto mode.</p>
        <h3>Request Body:</h3>
        <pre>{
  "autoMode": true // or false
}</pre>
        <h3>Response:</h3>
        <pre>{
  "success": true,
  "message": "Auto mode updated",
  "autoMode": true
}</pre>
    </div>
    
    <div class="endpoint">
        <h2>Test Tools</h2>
        <p>The following tools are available for testing:</p>
        <ul>
            <li><a href="test_data.php">Test Data Generator</a> - Simulates an ESP device sending random data to the API</li>
        </ul>
    </div>
</body>
</html>
