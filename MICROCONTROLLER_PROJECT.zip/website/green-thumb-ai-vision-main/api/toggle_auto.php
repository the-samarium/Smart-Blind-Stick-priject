
<?php
// Set headers to allow cross-origin requests
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("Access-Control-Allow-Methods: POST");
    exit(0);
}

// Check if this is a POST request
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get the raw POST data
    $postData = file_get_contents("php://input");
    
    // Try to decode the JSON data
    $data = json_decode($postData, true);
    
    // If valid JSON data was received
    if ($data !== null && isset($data['autoMode'])) {
        $autoMode = (bool)$data['autoMode'];
        
        // Update the sensor data file with the new auto mode status
        $dataFile = "data/sensor_data.json";
        
        if (file_exists($dataFile)) {
            $sensorData = json_decode(file_get_contents($dataFile), true);
            
            // Update the auto mode
            $sensorData['autoMode'] = $autoMode;
            
            // Save the updated data
            file_put_contents($dataFile, json_encode($sensorData, JSON_PRETTY_PRINT));
        }
        
        // Return success response
        echo json_encode([
            "success" => true, 
            "message" => "Auto mode updated",
            "autoMode" => $autoMode
        ]);
    } else {
        // Invalid or incomplete data
        http_response_code(400);
        echo json_encode([
            "success" => false, 
            "message" => "Invalid request data. Required field: autoMode"
        ]);
    }
    exit;
}

// For unsupported request methods
http_response_code(405);
echo json_encode(["success" => false, "message" => "Method not allowed"]);
?>
