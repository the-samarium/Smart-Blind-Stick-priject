
import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Leaf, Droplets, Mountain, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { toast } from "@/components/ui/use-toast";
import { SensorData, fetchLatestSensorData } from "@/lib/api";
import { SensorCard } from "@/components/dashboard/SensorCard";
import { NutrientPumpControl } from "@/components/dashboard/NutrientPumpControl";
import { AutoModeControl } from "@/components/dashboard/AutoModeControl";
import { BatteryStatus } from "@/components/dashboard/BatteryStatus";
import { AlertsPanel } from "@/components/dashboard/AlertsPanel";

const Dashboard = () => {
  const [sensorData, setSensorData] = useState<SensorData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const fetchData = async () => {
    try {
      setIsRefreshing(true);
      const data = await fetchLatestSensorData();
      setSensorData(data);
      setLastUpdated(new Date());
      setError(null);
    } catch (err) {
      setError("Failed to fetch sensor data");
      toast({
        title: "Error fetching data",
        description: "Could not retrieve the latest sensor readings.",
        variant: "destructive",
      });
      console.error(err);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchData();

    // Set up an interval to fetch data every 10 seconds
    const intervalId = setInterval(fetchData, 10000);

    // Clean up on unmount
    return () => clearInterval(intervalId);
  }, []);

  const handleRefresh = () => {
    fetchData();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-pulse text-lg">Loading dashboard data...</div>
      </div>
    );
  }

  if (error || !sensorData) {
    return (
      <div className="space-y-4 text-center">
        <h1 className="text-2xl font-bold text-red-600">Error Loading Dashboard</h1>
        <p>{error || "Unknown error occurred"}</p>
        <Button onClick={handleRefresh}>Try Again</Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Live Dashboard</h1>
          <p className="text-muted-foreground">
            Real-time sensor data and system controls for your precision farming.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {lastUpdated && (
            <p className="text-xs text-muted-foreground">
              Last updated: {format(lastUpdated, "HH:mm:ss")}
            </p>
          )}
          <Button 
            size="sm" 
            variant="outline" 
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="gap-1"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${isRefreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <SensorCard 
          title="Nitrogen Level" 
          value={sensorData.nitrogen} 
          unit="ppm" 
          icon={<Leaf className="h-4 w-4 text-nature-green" />} 
          color="bg-nature-green"
          isUpdating={isRefreshing}
        />
        <SensorCard 
          title="Phosphorus Level" 
          value={sensorData.phosphorus} 
          unit="ppm" 
          icon={<Mountain className="h-4 w-4 text-amber-500" />} 
          color="bg-amber-500"
          isUpdating={isRefreshing}
        />
        <SensorCard 
          title="Potassium Level" 
          value={sensorData.potassium} 
          unit="ppm" 
          icon={<Droplets className="h-4 w-4 text-blue-500" />} 
          color="bg-blue-500"
          isUpdating={isRefreshing}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <NutrientPumpControl 
          nutrient="nitrogen"
          initialPumpStatus={sensorData.pumpStatus.nitrogen} 
          autoMode={sensorData.autoMode}
          icon={<Leaf className="h-5 w-5 text-nature-green" />}
          color="#4caf50" 
        />
        <NutrientPumpControl 
          nutrient="phosphorus"
          initialPumpStatus={sensorData.pumpStatus.phosphorus} 
          autoMode={sensorData.autoMode}
          icon={<Mountain className="h-5 w-5 text-amber-500" />}
          color="#f59e0b" 
        />
        <NutrientPumpControl 
          nutrient="potassium"
          initialPumpStatus={sensorData.pumpStatus.potassium} 
          autoMode={sensorData.autoMode}
          icon={<Droplets className="h-5 w-5 text-blue-500" />}
          color="#3b82f6" 
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <AutoModeControl initialAutoMode={sensorData.autoMode} />
        <BatteryStatus batteryLevel={sensorData.batteryLevel} />
        <div className="md:col-span-1">
          <AlertsPanel />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
