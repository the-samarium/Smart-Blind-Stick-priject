
import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Battery, Bell, Droplet, Filter, Beaker, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertData, fetchAlerts } from "@/lib/api";
import { format, parseISO } from "date-fns";
import { toast } from "@/components/ui/use-toast";

const Alerts = () => {
  const [alerts, setAlerts] = useState<AlertData[]>([]);
  const [filteredAlerts, setFilteredAlerts] = useState<AlertData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [filterSeverity, setFilterSeverity] = useState("all");

  useEffect(() => {
    const getAlerts = async () => {
      try {
        setIsLoading(true);
        const data = await fetchAlerts();
        setAlerts(data);
        setFilteredAlerts(data);
        setError(null);
      } catch (err) {
        setError("Failed to fetch alerts");
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    };

    getAlerts();
  }, []);

  useEffect(() => {
    let result = alerts;
    
    // Apply type filter
    if (filterType !== "all") {
      result = result.filter(alert => alert.type === filterType);
    }
    
    // Apply severity filter
    if (filterSeverity !== "all") {
      result = result.filter(alert => alert.severity === filterSeverity);
    }
    
    // Apply search
    if (searchQuery) {
      result = result.filter(alert => 
        alert.message.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    setFilteredAlerts(result);
  }, [alerts, searchQuery, filterType, filterSeverity]);

  const getAlertIcon = (type: AlertData['type']) => {
    switch (type) {
      case 'battery':
        return <Battery className="h-4 w-4 text-yellow-500" />;
      case 'pump':
        return <Droplet className="h-4 w-4 text-blue-500" />;
      case 'fertilizer':
        return <Beaker className="h-4 w-4 text-green-500" />;
      case 'sensor':
      default:
        return <AlertTriangle className="h-4 w-4 text-red-500" />;
    }
  };

  const getSeverityBadge = (severity: AlertData['severity']) => {
    switch (severity) {
      case 'high':
        return <Badge variant="destructive">High</Badge>;
      case 'medium':
        return <Badge variant="default" className="bg-yellow-500">Medium</Badge>;
      case 'low':
      default:
        return <Badge variant="outline">Low</Badge>;
    }
  };

  const handleResolveAlert = (id: string) => {
    setAlerts(prev => prev.filter(alert => alert.id !== id));
    toast({
      title: "Alert Resolved",
      description: "The alert has been marked as resolved.",
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-pulse text-lg">Loading alerts...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="space-y-4 text-center">
        <h1 className="text-2xl font-bold text-red-600">Error Loading Alerts</h1>
        <p>{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">System Alerts</h1>
        <p className="text-muted-foreground">
          Monitor and resolve issues with your precision farming system.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base font-medium flex items-center gap-2">
            <Bell className="h-5 w-5 text-orange-500" />
            Alert Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search alerts..."
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex gap-4">
              <div className="w-[160px]">
                <Select
                  value={filterType}
                  onValueChange={setFilterType}
                >
                  <SelectTrigger>
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="sensor">Sensor</SelectItem>
                    <SelectItem value="battery">Battery</SelectItem>
                    <SelectItem value="pump">Pump</SelectItem>
                    <SelectItem value="fertilizer">Fertilizer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="w-[160px]">
                <Select
                  value={filterSeverity}
                  onValueChange={setFilterSeverity}
                >
                  <SelectTrigger>
                    <AlertTriangle className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Severity" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Severities</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {filteredAlerts.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground">
              <Bell className="h-10 w-10 mx-auto mb-3 text-muted" />
              <p>No alerts match your criteria</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredAlerts.map((alert) => (
                <Card key={alert.id} className="border-l-4 border-l-red-500">
                  <CardContent className="p-4">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="flex items-start gap-3">
                        <div className="mt-1">{getAlertIcon(alert.type)}</div>
                        <div>
                          <p className="font-medium">{alert.message}</p>
                          <p className="text-xs text-muted-foreground">
                            {format(parseISO(alert.timestamp), "MMM d, yyyy 'at' h:mm a")}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        {getSeverityBadge(alert.severity)}
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleResolveAlert(alert.id)}
                        >
                          Resolve
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Alerts;
