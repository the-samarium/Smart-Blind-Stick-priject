
import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Brain, ChevronRight, Lightbulb, TrendingUp, PlaneTakeoff } from "lucide-react";
import { AiInsight, fetchAiInsights } from "@/lib/api";
import { format, parseISO } from "date-fns";

const AiInsights = () => {
  const [insights, setInsights] = useState<AiInsight[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        const data = await fetchAiInsights();
        setInsights(data);
        setError(null);
      } catch (err) {
        setError("Failed to fetch AI insights");
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  const getInsightIcon = (type: AiInsight['type']) => {
    switch (type) {
      case 'prediction':
        return <TrendingUp className="h-5 w-5 text-purple-500" />;
      case 'recommendation':
        return <Lightbulb className="h-5 w-5 text-amber-500" />;
      case 'analysis':
      default:
        return <Brain className="h-5 w-5 text-blue-500" />;
    }
  };

  const getInsightBadge = (type: AiInsight['type']) => {
    switch (type) {
      case 'prediction':
        return <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-100">Prediction</Badge>;
      case 'recommendation':
        return <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">Recommendation</Badge>;
      case 'analysis':
      default:
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Analysis</Badge>;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-pulse text-lg">
          <Brain className="h-8 w-8 mb-4 mx-auto text-nature-green" />
          Loading AI insights...
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="space-y-4 text-center">
        <h1 className="text-2xl font-bold text-red-600">Error Loading Insights</h1>
        <p>{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">AI Insights</h1>
        <p className="text-muted-foreground">
          Smart recommendations and predictions based on your farm's data.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {insights.map((insight) => (
          <Card key={insight.id} className="transition-all hover:shadow-md">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                {getInsightIcon(insight.type)}
                {getInsightBadge(insight.type)}
              </div>
              <CardTitle className="text-lg mt-2">{insight.title}</CardTitle>
              <CardDescription>
                {insight.date && format(parseISO(insight.date), "MMM d, yyyy")}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm">{insight.description}</p>
            </CardContent>
            {insight.actionable && (
              <CardFooter>
                <Button className="w-full gap-1">
                  {insight.actionText}
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </CardFooter>
            )}
          </Card>
        ))}
      </div>

      <Card className="bg-gradient-farm mt-8">
        <CardHeader>
          <div className="flex items-center gap-2">
            <PlaneTakeoff className="h-6 w-6 text-nature-green-dark" />
            <CardTitle>AI Crop Planning Assistant</CardTitle>
          </div>
          <CardDescription>
            Get personalized planting schedules based on your soil data and local weather patterns
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm">
            Our advanced AI can analyze your historical soil data, local weather forecasts, and crop
            requirements to generate an optimal planting and fertilization schedule for your farm.
          </p>
        </CardContent>
        <CardFooter>
          <Button variant="outline" className="w-full bg-white hover:bg-white/90">Launch Crop Planner</Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default AiInsights;
