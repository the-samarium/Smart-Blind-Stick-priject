
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, TooltipProps } from "recharts";
import { format, subDays, subHours, subWeeks } from "date-fns";
import { Download, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";

// Sample data for demonstration
const generateDailyData = () => {
  const data = [];
  for (let i = 6; i >= 0; i--) {
    const date = subDays(new Date(), i);
    data.push({
      date: format(date, "MMM dd"),
      nitrogen: Math.floor(Math.random() * 30) + 70,
      phosphorus: Math.floor(Math.random() * 20) + 40,
      potassium: Math.floor(Math.random() * 25) + 55,
    });
  }
  return data;
};

const generateHourlyData = () => {
  const data = [];
  for (let i = 23; i >= 0; i--) {
    const date = subHours(new Date(), i);
    data.push({
      date: format(date, "HH:mm"),
      nitrogen: Math.floor(Math.random() * 10) + 75,
      phosphorus: Math.floor(Math.random() * 8) + 42,
      potassium: Math.floor(Math.random() * 10) + 58,
    });
  }
  return data;
};

const generateWeeklyData = () => {
  const data = [];
  for (let i = 11; i >= 0; i--) {
    const date = subWeeks(new Date(), i);
    data.push({
      date: format(date, "MMM dd"),
      nitrogen: Math.floor(Math.random() * 35) + 65,
      phosphorus: Math.floor(Math.random() * 25) + 35,
      potassium: Math.floor(Math.random() * 30) + 50,
    });
  }
  return data;
};

// Custom tooltip component
const CustomTooltip = ({ active, payload, label }: TooltipProps<number, string>) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-background border p-3 rounded-md shadow-md">
        <p className="font-medium">{`${label}`}</p>
        {payload.map((entry, index) => (
          <div key={`item-${index}`} className="flex items-center gap-2">
            <div className="w-3 h-3" style={{ backgroundColor: entry.color }} />
            <p className="text-sm">
              {`${entry.name}: ${entry.value} ppm`}
            </p>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

const HistoricalData = () => {
  const [timeRange, setTimeRange] = useState("daily");
  const [sensorFilter, setSensorFilter] = useState("all");
  const [isLoading, setIsLoading] = useState(false);

  const dailyData = generateDailyData();
  const hourlyData = generateHourlyData();
  const weeklyData = generateWeeklyData();

  const getActiveData = () => {
    switch (timeRange) {
      case "hourly":
        return hourlyData;
      case "weekly":
        return weeklyData;
      case "daily":
      default:
        return dailyData;
    }
  };

  // Function to get the sensor data to display based on the filter
  const getVisibleSensors = () => {
    if (sensorFilter === "all") return ["nitrogen", "phosphorus", "potassium"];
    return [sensorFilter];
  };

  const visibleSensors = getVisibleSensors();
  const data = getActiveData();

  const handleExportData = () => {
    const currentData = getActiveData();
    const csvContent = 
      "data:text/csv;charset=utf-8," + 
      "Date," + 
      visibleSensors.join(",") + 
      "\n" + 
      currentData.map(row => {
        return `${row.date},${visibleSensors.map(sensor => row[sensor as keyof typeof row]).join(",")}`;
      }).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `sensor_data_${timeRange}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getSensorColor = (sensor: string) => {
    switch (sensor) {
      case "nitrogen":
        return "#4caf50"; // Green
      case "phosphorus":
        return "#f59e0b"; // Amber
      case "potassium":
        return "#3b82f6"; // Blue
      default:
        return "#9333ea"; // Purple
    }
  };

  const getSensorName = (sensor: string) => {
    return sensor.charAt(0).toUpperCase() + sensor.slice(1);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Historical Data</h1>
        <p className="text-muted-foreground">
          View and analyze your sensor data history over time.
        </p>
      </div>

      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div className="flex flex-wrap gap-4">
          <div className="w-full sm:w-auto">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Select time range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="hourly">Last 24 Hours</SelectItem>
                <SelectItem value="daily">Last 7 Days</SelectItem>
                <SelectItem value="weekly">Last 12 Weeks</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="w-full sm:w-auto">
            <Select value={sensorFilter} onValueChange={setSensorFilter}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter sensors" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Sensors</SelectItem>
                <SelectItem value="nitrogen">Nitrogen Only</SelectItem>
                <SelectItem value="phosphorus">Phosphorus Only</SelectItem>
                <SelectItem value="potassium">Potassium Only</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <Button 
          variant="outline" 
          className="gap-1"
          onClick={handleExportData}
        >
          <Download className="h-4 w-4" />
          Export CSV
        </Button>
      </div>

      <Card className="w-full overflow-hidden">
        <CardHeader>
          <CardTitle>NPK Levels Over Time</CardTitle>
          <CardDescription>
            {timeRange === "hourly" && "Hourly readings for the past 24 hours"}
            {timeRange === "daily" && "Daily averages for the past 7 days"}
            {timeRange === "weekly" && "Weekly averages for the past 12 weeks"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="w-full h-[400px] flex items-center justify-center">
              <Skeleton className="w-full h-full" />
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={400}>
              <LineChart
                data={data}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" />
                <YAxis 
                  label={{ 
                    value: 'PPM', 
                    angle: -90, 
                    position: 'insideLeft' 
                  }} 
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                {visibleSensors.map((sensor) => (
                  <Line
                    key={sensor}
                    type="monotone"
                    dataKey={sensor}
                    name={sensor.charAt(0).toUpperCase() + sensor.slice(1)}
                    stroke={getSensorColor(sensor)}
                    strokeWidth={2}
                    dot={{ r: 3 }}
                    activeDot={{ r: 8 }}
                  />
                ))}
              </LineChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default HistoricalData;
