
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Settings2, Wifi, Bell, Shield, Save, Droplet } from "lucide-react";
import { toast } from "@/components/ui/use-toast";

const Settings = () => {
  const handleSave = () => {
    toast({
      title: "Settings Saved",
      description: "Your settings have been updated successfully."
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">System Settings</h1>
        <p className="text-muted-foreground">
          Configure your smart farming system parameters and preferences.
        </p>
      </div>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="network">Network</TabsTrigger>
          <TabsTrigger value="fertilizer">Fertilizer</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
        </TabsList>
        
        <TabsContent value="general" className="mt-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-medium flex items-center gap-2">
                <Settings2 className="h-5 w-5 text-muted-foreground" />
                General Settings
              </CardTitle>
              <CardDescription>
                Manage your system's general settings and preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="system-name">System Name</Label>
                <Input id="system-name" defaultValue="Main Farm Controller" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="location">Farm Location</Label>
                <Input id="location" defaultValue="Field A, North Sector" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="timezone">Timezone</Label>
                <Select defaultValue="utc-5">
                  <SelectTrigger id="timezone">
                    <SelectValue placeholder="Select Timezone" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="utc-8">Pacific Time (UTC-8)</SelectItem>
                    <SelectItem value="utc-7">Mountain Time (UTC-7)</SelectItem>
                    <SelectItem value="utc-6">Central Time (UTC-6)</SelectItem>
                    <SelectItem value="utc-5">Eastern Time (UTC-5)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="auto-updates">Automatic Updates</Label>
                  <p className="text-sm text-muted-foreground">
                    Keep your system up to date automatically
                  </p>
                </div>
                <Switch id="auto-updates" defaultChecked />
              </div>
              
              <Button onClick={handleSave} className="w-full">
                <Save className="h-4 w-4 mr-2" />
                Save Settings
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="network" className="mt-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-medium flex items-center gap-2">
                <Wifi className="h-5 w-5 text-muted-foreground" />
                Network Configuration
              </CardTitle>
              <CardDescription>
                Configure your system's connectivity settings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="wifi-ssid">Wi-Fi SSID</Label>
                <Input id="wifi-ssid" defaultValue="FarmNetwork" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="wifi-password">Wi-Fi Password</Label>
                <Input id="wifi-password" type="password" defaultValue="********" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="data-frequency">Data Transmission Frequency</Label>
                <Select defaultValue="5">
                  <SelectTrigger id="data-frequency">
                    <SelectValue placeholder="Select Frequency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">Every 1 minute</SelectItem>
                    <SelectItem value="5">Every 5 minutes</SelectItem>
                    <SelectItem value="15">Every 15 minutes</SelectItem>
                    <SelectItem value="30">Every 30 minutes</SelectItem>
                    <SelectItem value="60">Every hour</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="low-power-mode">Low Power Mode</Label>
                  <p className="text-sm text-muted-foreground">
                    Reduces data transmission frequency to save power
                  </p>
                </div>
                <Switch id="low-power-mode" />
              </div>
              
              <Button onClick={handleSave} className="w-full">
                <Save className="h-4 w-4 mr-2" />
                Save Network Settings
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="fertilizer" className="mt-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-medium flex items-center gap-2">
                <Droplet className="h-5 w-5 text-muted-foreground" />
                Fertilizer Control Settings
              </CardTitle>
              <CardDescription>
                Configure fertilizer application parameters
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Nitrogen Threshold (Auto-Mode)</Label>
                <div className="pt-2">
                  <Slider defaultValue={[40]} max={100} step={1} />
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>Low (0 ppm)</span>
                  <span>40 ppm</span>
                  <span>High (100 ppm)</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Phosphorus Threshold (Auto-Mode)</Label>
                <div className="pt-2">
                  <Slider defaultValue={[30]} max={100} step={1} />
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>Low (0 ppm)</span>
                  <span>30 ppm</span>
                  <span>High (100 ppm)</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Potassium Threshold (Auto-Mode)</Label>
                <div className="pt-2">
                  <Slider defaultValue={[50]} max={100} step={1} />
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>Low (0 ppm)</span>
                  <span>50 ppm</span>
                  <span>High (100 ppm)</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="fertilizer-type">Fertilizer Type</Label>
                <Select defaultValue="npk">
                  <SelectTrigger id="fertilizer-type">
                    <SelectValue placeholder="Select Fertilizer Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="npk">Balanced NPK (10-10-10)</SelectItem>
                    <SelectItem value="nitrogen">Nitrogen-Rich (20-5-5)</SelectItem>
                    <SelectItem value="phosphorus">Phosphorus-Rich (5-20-5)</SelectItem>
                    <SelectItem value="potassium">Potassium-Rich (5-5-20)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button onClick={handleSave} className="w-full">
                <Save className="h-4 w-4 mr-2" />
                Save Fertilizer Settings
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="notifications" className="mt-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-medium flex items-center gap-2">
                <Bell className="h-5 w-5 text-muted-foreground" />
                Notification Settings
              </CardTitle>
              <CardDescription>
                Configure how and when you receive system notifications
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Critical Alerts</Label>
                  <p className="text-sm text-muted-foreground">
                    System failures and urgent issues
                  </p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Nutrient Level Alerts</Label>
                  <p className="text-sm text-muted-foreground">
                    When nutrient levels fall below threshold
                  </p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Battery Alerts</Label>
                  <p className="text-sm text-muted-foreground">
                    When battery levels are low
                  </p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>AI Recommendations</Label>
                  <p className="text-sm text-muted-foreground">
                    New insights and recommendations
                  </p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="notification-email">Email Notifications</Label>
                <Input id="notification-email" type="email" placeholder="farm@example.com" />
              </div>
              
              <Button onClick={handleSave} className="w-full">
                <Save className="h-4 w-4 mr-2" />
                Save Notification Settings
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Settings;
