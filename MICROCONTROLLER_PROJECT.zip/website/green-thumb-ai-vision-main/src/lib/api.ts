
// API service that connects to a PHP backend
// Falls back to mock data when not connected to the backend

export interface SensorData {
  timestamp: string;
  nitrogen: number;
  phosphorus: number;
  potassium: number;
  batteryLevel: number;
  pumpStatus: {
    nitrogen: 'ON' | 'OFF';
    phosphorus: 'ON' | 'OFF';
    potassium: 'ON' | 'OFF';
  };
  autoMode: boolean;
}

export interface AlertData {
  id: string;
  type: 'sensor' | 'battery' | 'pump' | 'fertilizer';
  message: string;
  severity: 'low' | 'medium' | 'high';
  timestamp: string;
}

export interface AiInsight {
  id: string;
  type: 'prediction' | 'recommendation' | 'analysis';
  title: string;
  description: string;
  date: string;
  actionable: boolean;
  actionText?: string;
}

// Base API URL - change this to your server URL
const API_BASE_URL = '/api';

// Check if we can connect to the PHP backend
async function isBackendAvailable() {
  try {
    const response = await fetch(`${API_BASE_URL}/receive_data.php`, { 
      method: 'GET',
      headers: { 'Accept': 'application/json' },
      // Short timeout to quickly determine if backend is available
      signal: AbortSignal.timeout(2000)
    });
    return response.ok;
  } catch (error) {
    console.log('Backend not available, using mock data:', error);
    return false;
  }
}

// Mock functions to simulate real-time data when backend is unavailable
function getRandomValue(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Fetch the latest sensor data from the backend or generate mock data
export const fetchLatestSensorData = async (): Promise<SensorData> => {
  try {
    if (await isBackendAvailable()) {
      const response = await fetch(`${API_BASE_URL}/receive_data.php`);
      if (response.ok) {
        const data = await response.json();
        return data as SensorData;
      } else {
        throw new Error(`Failed to fetch data: ${response.status}`);
      }
    }
  } catch (error) {
    console.error('Error fetching sensor data:', error);
    // Fall back to mock data
  }
  
  // Return mock data if backend is unavailable or there was an error
  return {
    timestamp: new Date().toISOString(),
    nitrogen: getRandomValue(30, 80),
    phosphorus: getRandomValue(20, 60),
    potassium: getRandomValue(40, 90),
    batteryLevel: getRandomValue(20, 100),
    pumpStatus: {
      nitrogen: Math.random() > 0.5 ? 'ON' : 'OFF',
      phosphorus: Math.random() > 0.5 ? 'ON' : 'OFF',
      potassium: Math.random() > 0.5 ? 'ON' : 'OFF',
    },
    autoMode: Math.random() > 0.3
  };
};

// Fetch historical data from the backend or generate mock data
export const fetchHistoricalData = async (days: number = 7): Promise<SensorData[]> => {
  try {
    if (await isBackendAvailable()) {
      const response = await fetch(`${API_BASE_URL}/get_history.php?days=${days}`);
      if (response.ok) {
        const data = await response.json();
        return data as SensorData[];
      } else {
        throw new Error(`Failed to fetch historical data: ${response.status}`);
      }
    }
  } catch (error) {
    console.error('Error fetching historical data:', error);
    // Fall back to mock data
  }
  
  // Generate mock historical data
  const data: SensorData[] = [];
  const now = new Date();
  
  for (let i = 0; i < days * 24; i++) { // Hourly data points
    const timestamp = new Date(now);
    timestamp.setHours(now.getHours() - i);
    
    data.push({
      timestamp: timestamp.toISOString(),
      nitrogen: getRandomValue(30, 80),
      phosphorus: getRandomValue(20, 60),
      potassium: getRandomValue(40, 90),
      batteryLevel: getRandomValue(20, 100),
      pumpStatus: {
        nitrogen: Math.random() > 0.5 ? 'ON' : 'OFF',
        phosphorus: Math.random() > 0.5 ? 'ON' : 'OFF',
        potassium: Math.random() > 0.5 ? 'ON' : 'OFF',
      },
      autoMode: Math.random() > 0.3
    });
  }
  
  return data.reverse(); // Reverse to get chronological order
};

// Simulate fetching alerts (mock only, not implemented in PHP backend)
export const fetchAlerts = (): Promise<AlertData[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        {
          id: '1',
          type: 'battery',
          message: 'Low battery level on Sensor Node 2',
          severity: 'medium',
          timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString() // 30 mins ago
        },
        {
          id: '2',
          type: 'sensor',
          message: 'Nitrogen sensor reading anomaly detected',
          severity: 'high',
          timestamp: new Date(Date.now() - 1000 * 60 * 120).toISOString() // 2 hours ago
        },
        {
          id: '3',
          type: 'fertilizer',
          message: 'Phosphorus levels critically low in Zone B',
          severity: 'high',
          timestamp: new Date(Date.now() - 1000 * 60 * 240).toISOString() // 4 hours ago
        },
        {
          id: '4',
          type: 'pump',
          message: 'Fertilizer pump 1 inactive for 24 hours',
          severity: 'low',
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 25).toISOString() // 25 hours ago
        }
      ]);
    }, 600);
  });
};

// Simulate fetching AI insights (mock only, not implemented in PHP backend)
export const fetchAiInsights = (): Promise<AiInsight[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        {
          id: '1',
          type: 'prediction',
          title: 'Nitrogen Depletion Forecasted',
          description: 'Based on current trends, nitrogen levels will reach critical levels in 5-7 days.',
          date: new Date(Date.now() + 1000 * 60 * 60 * 24 * 6).toISOString(), // 6 days from now
          actionable: true,
          actionText: 'Schedule Fertilization'
        },
        {
          id: '2',
          type: 'recommendation',
          title: 'Optimize Phosphorus Application',
          description: 'Current soil conditions suggest reducing phosphorus application by 15% would maintain yield while reducing costs.',
          date: new Date().toISOString(),
          actionable: true,
          actionText: 'Update Fertilizer Plan'
        },
        {
          id: '3',
          type: 'analysis',
          title: 'NPK Balance Analysis',
          description: 'Your current NPK ratio is optimal for the vegetative growth phase of your crops.',
          date: new Date().toISOString(),
          actionable: false
        }
      ]);
    }, 700);
  });
};

// Toggle a pump via the PHP API
export const togglePump = async (
  nutrient: 'nitrogen' | 'phosphorus' | 'potassium', 
  pumpState: 'ON' | 'OFF'
): Promise<{success: boolean}> => {
  try {
    if (await isBackendAvailable()) {
      const response = await fetch(`${API_BASE_URL}/control_pump.php`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          nutrient: nutrient,
          state: pumpState,
        }),
      });
      
      if (response.ok) {
        const result = await response.json();
        console.log(`${nutrient.charAt(0).toUpperCase() + nutrient.slice(1)} pump toggled to ${pumpState}`);
        return { success: true };
      } else {
        throw new Error(`Failed to toggle pump: ${response.status}`);
      }
    }
  } catch (error) {
    console.error('Error toggling pump:', error);
  }
  
  // Return success for mock mode
  console.log(`${nutrient.charAt(0).toUpperCase() + nutrient.slice(1)} pump toggled to ${pumpState} (mock)`);
  return { success: true };
};

// Toggle auto mode via the PHP API
export const toggleAutoMode = async (autoModeState: boolean): Promise<{success: boolean}> => {
  try {
    if (await isBackendAvailable()) {
      const response = await fetch(`${API_BASE_URL}/toggle_auto.php`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          autoMode: autoModeState,
        }),
      });
      
      if (response.ok) {
        const result = await response.json();
        console.log(`Auto mode toggled to ${autoModeState}`);
        return { success: true };
      } else {
        throw new Error(`Failed to toggle auto mode: ${response.status}`);
      }
    }
  } catch (error) {
    console.error('Error toggling auto mode:', error);
  }
  
  // Return success for mock mode
  console.log(`Auto mode toggled to ${autoModeState} (mock)`);
  return { success: true };
};
