
import { useState } from "react";
import { NavLink } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { 
  LayoutDashboard, 
  LineChart, 
  Brain, 
  Settings, 
  AlertTriangle, 
  Menu, 
  X, 
  Leaf 
} from "lucide-react";
import { cn } from "@/lib/utils";

interface NavItemProps {
  to: string;
  icon: React.ReactNode;
  label: string;
  isCollapsed: boolean;
}

const NavItem = ({ to, icon, label, isCollapsed }: NavItemProps) => {
  return (
    <NavLink 
      to={to} 
      className={({ isActive }) => cn(
        "flex items-center gap-2 p-3 rounded-lg transition-colors hover:bg-nature-green-light/20 hover:text-nature-green-dark",
        isActive ? "bg-nature-green-light/30 text-nature-green-dark font-medium" : "text-muted-foreground",
        isCollapsed && "justify-center"
      )}
    >
      {icon}
      {!isCollapsed && <span>{label}</span>}
    </NavLink>
  );
};

export function Sidebar() {
  const [isCollapsed, setIsCollapsed] = useState(false);

  return (
    <div 
      className={cn(
        "border-r border-border bg-card h-screen flex flex-col transition-all duration-300 ease-in-out",
        isCollapsed ? "w-16" : "w-64"
      )}
    >
      <div className="p-4 flex items-center justify-between border-b border-border">
        <div className={cn("flex items-center gap-2", isCollapsed && "justify-center w-full")}>
          <Leaf className="h-6 w-6 text-nature-green" />
          {!isCollapsed && <span className="font-bold text-xl">GreenThumb AI</span>}
        </div>
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => setIsCollapsed(!isCollapsed)}
          className={isCollapsed ? "ml-auto" : ""}
        >
          {isCollapsed ? <Menu className="h-5 w-5" /> : <X className="h-5 w-5" />}
        </Button>
      </div>
      
      <div className="flex-1 py-4 overflow-y-auto">
        <nav className="px-2 space-y-1">
          <NavItem 
            to="/" 
            icon={<LayoutDashboard className="h-5 w-5" />} 
            label="Dashboard" 
            isCollapsed={isCollapsed}
          />
          <NavItem 
            to="/historical" 
            icon={<LineChart className="h-5 w-5" />} 
            label="Historical Data" 
            isCollapsed={isCollapsed}
          />
          <NavItem 
            to="/ai-insights" 
            icon={<Brain className="h-5 w-5" />} 
            label="AI Insights" 
            isCollapsed={isCollapsed}
          />
          <NavItem 
            to="/alerts" 
            icon={<AlertTriangle className="h-5 w-5" />} 
            label="Alerts" 
            isCollapsed={isCollapsed}
          />
          <NavItem 
            to="/settings" 
            icon={<Settings className="h-5 w-5" />} 
            label="Settings" 
            isCollapsed={isCollapsed}
          />
        </nav>
      </div>
      
      <div className="p-4 border-t border-border">
        <div className={cn(
          "flex items-center gap-2 text-sm text-muted-foreground",
          isCollapsed && "justify-center"
        )}>
          {!isCollapsed && (
            <span>v1.0.0</span>
          )}
        </div>
      </div>
    </div>
  );
}
