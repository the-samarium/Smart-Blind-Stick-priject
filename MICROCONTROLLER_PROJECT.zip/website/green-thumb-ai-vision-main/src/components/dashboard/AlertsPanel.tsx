
import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, BellRing, Battery, Droplet, Beaker } from "lucide-react";
import { AlertData, fetchAlerts } from "@/lib/api";
import { format, formatDistanceToNow } from "date-fns";

export function AlertsPanel() {
  const [alerts, setAlerts] = useState<AlertData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const getAlerts = async () => {
      try {
        setIsLoading(true);
        const data = await fetchAlerts();
        setAlerts(data);
        setError(null);
      } catch (err) {
        setError("Failed to fetch alerts");
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    };

    getAlerts();
  }, []);

  const getAlertIcon = (type: AlertData['type']) => {
    switch (type) {
      case 'battery':
        return <Battery className="h-4 w-4" />;
      case 'pump':
        return <Droplet className="h-4 w-4" />;
      case 'fertilizer':
        return <Beaker className="h-4 w-4" />;
      case 'sensor':
      default:
        return <AlertTriangle className="h-4 w-4" />;
    }
  };

  const getSeverityBadge = (severity: AlertData['severity']) => {
    switch (severity) {
      case 'high':
        return <Badge variant="destructive">High</Badge>;
      case 'medium':
        return <Badge variant="default" className="bg-yellow-500">Medium</Badge>;
      case 'low':
      default:
        return <Badge variant="outline">Low</Badge>;
    }
  };

  return (
    <Card className="dashboard-card h-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-medium flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BellRing className="h-5 w-5 text-orange-500" />
            System Alerts
          </div>
          {alerts.length > 0 && (
            <Badge variant="outline" className="bg-red-50 text-red-700 hover:bg-red-50">
              {alerts.length} {alerts.length === 1 ? 'Alert' : 'Alerts'}
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4 max-h-[300px] overflow-y-auto">
        {isLoading ? (
          <div className="flex justify-center items-center h-32">
            <div className="animate-pulse">Loading alerts...</div>
          </div>
        ) : error ? (
          <div className="text-center text-red-500 py-4">
            <AlertTriangle className="h-6 w-6 mx-auto mb-2" />
            {error}
          </div>
        ) : alerts.length === 0 ? (
          <div className="text-center text-muted-foreground py-4">
            No alerts at this time
          </div>
        ) : (
          <div className="space-y-3">
            {alerts.map((alert) => (
              <div key={alert.id} className="border-b pb-3 last:border-0">
                <div className="flex justify-between items-start mb-1">
                  <div className="flex items-center gap-2">
                    {getAlertIcon(alert.type)}
                    <span className="font-medium text-sm">{alert.message}</span>
                  </div>
                  {getSeverityBadge(alert.severity)}
                </div>
                <div className="flex justify-between items-center mt-2">
                  <span className="text-xs text-muted-foreground">
                    {formatDistanceToNow(new Date(alert.timestamp), { addSuffix: true })}
                  </span>
                  <Button variant="ghost" size="sm" className="h-7 text-xs">
                    Resolve
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
