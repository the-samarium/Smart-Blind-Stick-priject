
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { toast } from "@/components/ui/use-toast";
import { Droplet, Power } from "lucide-react";
import { togglePump, toggleAutoMode } from "@/lib/api";

interface PumpControlProps {
  initialPumpStatus: 'ON' | 'OFF';
  initialAutoMode: boolean;
}

export function PumpControl({ initialPumpStatus, initialAutoMode }: PumpControlProps) {
  const [pumpStatus, setPumpStatus] = useState<'ON' | 'OFF'>(initialPumpStatus);
  const [autoMode, setAutoMode] = useState(initialAutoMode);
  const [isPending, setIsPending] = useState(false);

  const handleTogglePump = async () => {
    if (autoMode) {
      toast({
        title: "Cannot toggle pump manually",
        description: "Disable auto mode first to control the pump manually.",
        variant: "destructive"
      });
      return;
    }
    
    setIsPending(true);
    const newStatus = pumpStatus === 'ON' ? 'OFF' : 'ON';
    
    try {
      // Pass both nutrient type and pump state to togglePump
      const response = await togglePump('nitrogen', newStatus);
      if (response.success) {
        setPumpStatus(newStatus);
        toast({
          title: "Pump Control",
          description: `Pump has been turned ${newStatus.toLowerCase()}.`,
        });
      }
    } catch (error) {
      toast({
        title: "Error toggling pump",
        description: "There was an error controlling the pump. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsPending(false);
    }
  };

  const handleToggleAutoMode = async (checked: boolean) => {
    setIsPending(true);
    
    try {
      const response = await toggleAutoMode(checked);
      if (response.success) {
        setAutoMode(checked);
        toast({
          title: "Auto Mode",
          description: `Auto mode has been ${checked ? 'enabled' : 'disabled'}.`,
        });
      }
    } catch (error) {
      toast({
        title: "Error toggling auto mode",
        description: "There was an error toggling auto mode. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsPending(false);
    }
  };

  return (
    <Card className="dashboard-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-medium flex items-center gap-2">
          <Droplet className="h-5 w-5 text-blue-500" />
          Fertilizer Pump Control
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-col space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="pump-status" className="text-sm text-muted-foreground">Pump Status</Label>
            <span className={`text-sm px-2 py-0.5 rounded ${
              pumpStatus === 'ON' 
                ? 'bg-green-100 text-green-800' 
                : 'bg-red-100 text-red-800'
            }`}>
              {pumpStatus}
            </span>
          </div>
          
          <Button 
            onClick={handleTogglePump}
            disabled={autoMode || isPending}
            variant={pumpStatus === 'ON' ? "destructive" : "default"}
            className="w-full"
          >
            <Power className="h-4 w-4 mr-2" />
            Turn Pump {pumpStatus === 'ON' ? 'OFF' : 'ON'}
          </Button>
        </div>
        
        <div className="pt-2 border-t">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="auto-mode" className="text-sm">
                Auto Mode
              </Label>
              <p className="text-xs text-muted-foreground">
                Let AI control fertilization based on sensor data
              </p>
            </div>
            <Switch
              id="auto-mode"
              checked={autoMode}
              onCheckedChange={handleToggleAutoMode}
              disabled={isPending}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
