
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Battery, BatteryFull, BatteryLow, BatteryMedium, BatteryWarning } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface BatteryStatusProps {
  batteryLevel: number;
}

export function BatteryStatus({ batteryLevel }: BatteryStatusProps) {
  const getBatteryIcon = () => {
    if (batteryLevel >= 75) return <BatteryFull className="h-5 w-5 text-green-500" />;
    if (batteryLevel >= 50) return <Battery className="h-5 w-5 text-green-500" />;
    if (batteryLevel >= 25) return <BatteryMedium className="h-5 w-5 text-yellow-500" />;
    if (batteryLevel >= 10) return <BatteryLow className="h-5 w-5 text-orange-500" />;
    return <BatteryWarning className="h-5 w-5 text-red-500" />;
  };

  const getStatusColor = () => {
    if (batteryLevel >= 50) return "bg-green-500";
    if (batteryLevel >= 25) return "bg-yellow-500";
    return "bg-red-500";
  };

  return (
    <Card className="dashboard-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-medium flex items-center gap-2">
          {getBatteryIcon()}
          Sensor Battery Status
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        <div className="flex justify-between items-center">
          <span className="text-sm text-muted-foreground">Level</span>
          <span className={`text-sm font-medium ${
            batteryLevel < 25 ? 'text-red-500' : batteryLevel < 50 ? 'text-yellow-500' : 'text-green-500'
          }`}>
            {batteryLevel}%
          </span>
        </div>
        <Progress value={batteryLevel} className="h-2" indicatorClassName={getStatusColor()} />
        <p className="text-xs text-muted-foreground pt-1">
          {batteryLevel < 15 
            ? "Critical: Recharge or replace battery soon" 
            : batteryLevel < 30 
              ? "Low: Consider recharging soon" 
              : "Battery level is good"}
        </p>
      </CardContent>
    </Card>
  );
}
