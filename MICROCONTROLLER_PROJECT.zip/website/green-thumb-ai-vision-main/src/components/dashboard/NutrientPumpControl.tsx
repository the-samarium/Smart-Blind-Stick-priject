
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "@/components/ui/use-toast";
import { Power } from "lucide-react";
import { togglePump } from "@/lib/api";

type NutrientType = 'nitrogen' | 'phosphorus' | 'potassium';

interface NutrientPumpControlProps {
  nutrient: NutrientType;
  initialPumpStatus: 'ON' | 'OFF';
  autoMode: boolean;
  icon: React.ReactNode;
  color: string;
}

export function NutrientPumpControl({ 
  nutrient, 
  initialPumpStatus, 
  autoMode, 
  icon,
  color 
}: NutrientPumpControlProps) {
  const [pumpStatus, setPumpStatus] = useState<'ON' | 'OFF'>(initialPumpStatus);
  const [isPending, setIsPending] = useState(false);
  
  const nutrientLabel = nutrient.charAt(0).toUpperCase() + nutrient.slice(1);

  const handleTogglePump = async () => {
    if (autoMode) {
      toast({
        title: "Cannot toggle pump manually",
        description: "Disable auto mode first to control the pump manually.",
        variant: "destructive"
      });
      return;
    }
    
    setIsPending(true);
    const newStatus = pumpStatus === 'ON' ? 'OFF' : 'ON';
    
    try {
      const response = await togglePump(nutrient, newStatus);
      if (response.success) {
        setPumpStatus(newStatus);
        toast({
          title: `${nutrientLabel} Pump Control`,
          description: `${nutrientLabel} pump has been turned ${newStatus.toLowerCase()}.`,
        });
      }
    } catch (error) {
      toast({
        title: "Error toggling pump",
        description: `There was an error controlling the ${nutrientLabel} pump. Please try again.`,
        variant: "destructive"
      });
    } finally {
      setIsPending(false);
    }
  };

  // Get background color class based on nutrient type
  const getBadgeColorClass = () => {
    switch (nutrient) {
      case 'nitrogen':
        return 'bg-green-100 text-green-800';
      case 'phosphorus':
        return 'bg-amber-100 text-amber-800';
      case 'potassium':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Get button color variant based on nutrient type
  const getButtonColorVariant = () => {
    if (pumpStatus === 'ON') return "destructive";
    
    switch (nutrient) {
      case 'nitrogen':
        return "default";
      case 'phosphorus':
        return "default";
      case 'potassium':
        return "default";
      default:
        return "default";
    }
  };

  return (
    <Card className="dashboard-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-medium flex items-center gap-2">
          {icon}
          {nutrientLabel} Pump Control
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-col space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Pump Status</span>
            <span className={`text-sm px-2 py-0.5 rounded ${getBadgeColorClass()}`}>
              {pumpStatus}
            </span>
          </div>
          
          <Button 
            onClick={handleTogglePump}
            disabled={autoMode || isPending}
            variant={getButtonColorVariant()}
            className="w-full"
            style={{ backgroundColor: pumpStatus === 'OFF' && color ? color : undefined }}
          >
            <Power className="h-4 w-4 mr-2" />
            Turn Pump {pumpStatus === 'ON' ? 'OFF' : 'ON'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
