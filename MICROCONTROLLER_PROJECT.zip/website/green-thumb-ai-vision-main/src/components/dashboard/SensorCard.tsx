
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface SensorCardProps {
  title: string;
  value: number;
  unit: string;
  icon: React.ReactNode;
  color: string;
  isUpdating?: boolean;
}

export function SensorCard({ title, value, unit, icon, color, isUpdating = false }: SensorCardProps) {
  return (
    <Card className="dashboard-card overflow-hidden">
      <div className={`h-1 w-full ${color}`}></div>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <div className={`p-2 rounded-full ${color.replace('bg-', 'bg-opacity-20 ')}`}>
          {icon}
        </div>
      </CardHeader>
      <CardContent>
        <div className={cn("nutrient-value flex items-end gap-1", isUpdating && "data-updating")}>
          <span className="text-3xl font-bold">{value}</span>
          <span className="text-sm text-muted-foreground mb-1">{unit}</span>
        </div>
      </CardContent>
    </Card>
  );
}
