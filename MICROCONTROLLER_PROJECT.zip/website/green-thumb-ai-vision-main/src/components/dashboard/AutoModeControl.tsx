
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { toast } from "@/components/ui/use-toast";
import { Sparkles } from "lucide-react";
import { toggleAutoMode } from "@/lib/api";

interface AutoModeControlProps {
  initialAutoMode: boolean;
  onAutoModeChange?: (autoMode: boolean) => void;
}

export function AutoModeControl({ initialAutoMode, onAutoModeChange }: AutoModeControlProps) {
  const [autoMode, setAutoMode] = useState(initialAutoMode);
  const [isPending, setIsPending] = useState(false);

  const handleToggleAutoMode = async (checked: boolean) => {
    setIsPending(true);
    
    try {
      const response = await toggleAutoMode(checked);
      if (response.success) {
        setAutoMode(checked);
        if (onAutoModeChange) onAutoModeChange(checked);
        
        toast({
          title: "Auto Mode",
          description: `Auto mode has been ${checked ? 'enabled' : 'disabled'}.`,
        });
      }
    } catch (error) {
      toast({
        title: "Error toggling auto mode",
        description: "There was an error toggling auto mode. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsPending(false);
    }
  };

  return (
    <Card className="dashboard-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-medium flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-purple-500" />
          Smart Fertilization Control
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="auto-mode" className="text-sm">
              Auto Mode
            </Label>
            <p className="text-xs text-muted-foreground">
              Let AI control fertilization based on sensor data
            </p>
          </div>
          <Switch
            id="auto-mode"
            checked={autoMode}
            onCheckedChange={handleToggleAutoMode}
            disabled={isPending}
          />
        </div>
      </CardContent>
    </Card>
  );
}
